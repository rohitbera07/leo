# create-leo

`create-leo` is a small, production-oriented backend generator for Node.js, FastAPI, databases, and RAG.

## Requirements

- Node.js 22+
- Python 3.11+ for Python templates
- `uv` is recommended for Python dependency installation, but Leo falls back to `venv` + `pip`

## Use

```bash
npx create-leo my-api
```

Choose one of seven templates:

| ID | Stack |
|---|---|
| `express-mongodb` | Express 5 + Mongoose + MongoDB |
| `express-postgres` | Express 5 + pg + PostgreSQL |
| `fastify-postgres` | Fastify + pg + PostgreSQL |
| `fastapi-postgres` | FastAPI + SQLAlchemy + PostgreSQL |
| `fastapi-mongodb` | FastAPI + native async PyMongo |
| `semantic` | FastAPI + FastEmbed + local Qdrant + OpenAI-compatible LLM |
| `hybrid` | Semantic + BM25 + RRF + optional cross-encoder |

### Non-interactive

```bash
npx create-leo my-api --template express-mongodb
npx create-leo my-rag --template hybrid --no-install
npx create-leo --list
```

`--no-install` is useful for CI, smoke tests, or when you want to install dependencies yourself.

## Design choices

- Node 22 native `--watch` and `--env-file`; no nodemon or dotenv.
- ESM everywhere in Node templates.
- Express 5 async handlers; no custom async wrapper.
- FastAPI configuration uses `pydantic-settings`.
- MongoDB Python uses PyMongo's async client rather than Motor.
- RAG uses FastEmbed/ONNX rather than sentence-transformers + torch.
- Qdrant runs in local file mode; no Qdrant server is required for the starter.
- LLM calls use the OpenAI client with configurable `LLM_BASE_URL`.
- No LangChain dependency.
- Hybrid RAG overlays the semantic pipeline instead of duplicating ingestion.
- Every template has a DB-independent `/health` endpoint.

## Free-tier development

The generated projects do not require a paid service. For hosted free tiers, use a provider appropriate to the database you choose, or run the database locally. RAG's local Qdrant storage is file-based. An LLM key is only needed when you want generated answers rather than retrieved context.

The first FastEmbed query downloads its embedding model. This is expected.

## Publishing

Before publishing, verify the package name is available:

```bash
npm view create-leo
node scripts/check-name.mjs
```

If it is unavailable, use `create-leo-cli` or a scoped package.

Then:

```bash
npm login
npm publish
```

The `prepublishOnly` script resolves current Node dependency versions, builds `dist`, and runs tests.

## Testing

```bash
npm install
npm test
npm run build
```

CI generates all templates with `--no-install` and checks their basic filesystem output.

## License

MIT
